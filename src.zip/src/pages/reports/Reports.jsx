import { useEffect, useState } from 'react'
import { getTrips } from '../../firebase/trips'
import { getTrucks } from '../../firebase/trucks'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

const MONTHS = ['ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.']

// คำนวณรายรับรวมต่อ trip (ขาไป + ขากลับ + รายรับอื่นๆ ทุกส่วน)
function calcTotalIncome(trip) {
  const go = Number(trip.agreedIncome || 0) + Number(trip.otherIncome || 0)
  const ret = trip.hasReturn
    ? Number(trip.returnAgreedIncome || 0) + Number(trip.returnOtherIncome || 0)
    : 0
  return go + ret
}

export default function Reports() {
  const [trips, setTrips] = useState([])
  const [trucks, setTrucks] = useState([])
  const [selectedTruck, setSelectedTruck] = useState('')
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear())

  useEffect(() => {
    async function load() {
      const [tr, tk] = await Promise.all([getTrips(), getTrucks()])
      setTrips(tr)
      setTrucks(tk)
    }
    load()
  }, [])

  const totalExp = (exp = {}) =>
    ['fuel','driver','toll','bridge','oilChange','tire','other'].reduce((s, k) => s + (Number(exp[k]) || 0), 0)

  const filteredTrips = trips.filter(t => {
    if (selectedTruck && t.truckId !== selectedTruck) return false
    if (!t.tripDate) return false
    return new Date(t.tripDate).getFullYear() === selectedYear
  })

  // สร้างข้อมูลกราฟรายเดือน
  const chartData = MONTHS.map((month, i) => {
    const monthTrips = filteredTrips.filter(t => new Date(t.tripDate).getMonth() === i)
    const income = monthTrips.reduce((s, t) => s + calcTotalIncome(t), 0)
    const expense = monthTrips.reduce((s, t) => s + totalExp(t.expenses), 0)
    return { month, income, expense, profit: income - expense }
  })

  // สรุปรายรถ
  const truckSummary = trucks.map(truck => {
    const truckTrips = filteredTrips.filter(t => t.truckId === truck.id)
    const income = truckTrips.reduce((s, t) => s + calcTotalIncome(t), 0)
    const expense = truckTrips.reduce((s, t) => s + totalExp(t.expenses), 0)
    return { truck, trips: truckTrips.length, income, expense, profit: income - expense }
  }).filter(s => s.trips > 0)

  const totalIncome = filteredTrips.reduce((s, t) => s + calcTotalIncome(t), 0)
  const totalExpense = filteredTrips.reduce((s, t) => s + totalExp(t.expenses), 0)
  const totalProfit = totalIncome - totalExpense

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold text-gray-800">รายงาน</h1>
        <div className="flex gap-3">
          <select value={selectedTruck} onChange={e => setSelectedTruck(e.target.value)}
            className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
            <option value="">ทุกคัน</option>
            {trucks.map(t => <option key={t.id} value={t.id}>{t.plate}</option>)}
          </select>
          <select value={selectedYear} onChange={e => setSelectedYear(Number(e.target.value))}
            className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
            {[2567, 2568, 2569].map(y => <option key={y} value={y - 543}>{y}</option>)}
          </select>
        </div>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 text-center">
          <p className="text-xs text-gray-500 mb-1">รายรับรวม</p>
          <p className="text-xl font-bold text-green-600">฿{totalIncome.toLocaleString()}</p>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 text-center">
          <p className="text-xs text-gray-500 mb-1">รายจ่ายรวม</p>
          <p className="text-xl font-bold text-red-500">฿{totalExpense.toLocaleString()}</p>
        </div>
        <div className={`rounded-xl p-4 shadow-sm border text-center ${totalProfit >= 0 ? 'bg-blue-50 border-blue-100' : 'bg-orange-50 border-orange-100'}`}>
          <p className="text-xs text-gray-500 mb-1">กำไรสุทธิ</p>
          <p className={`text-xl font-bold ${totalProfit >= 0 ? 'text-blue-600' : 'text-orange-500'}`}>฿{totalProfit.toLocaleString()}</p>
        </div>
      </div>

      {/* Chart */}
      <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 mb-6">
        <h2 className="font-bold text-gray-700 mb-4">กราฟรายรับ-รายจ่าย รายเดือน</h2>
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" tick={{ fontSize: 12 }} />
            <YAxis tick={{ fontSize: 11 }} tickFormatter={v => `${(v/1000).toFixed(0)}k`} />
            <Tooltip formatter={v => `฿${v.toLocaleString()}`} />
            <Legend />
            <Bar dataKey="income" name="รายรับ" fill="#22c55e" radius={[4,4,0,0]} />
            <Bar dataKey="expense" name="รายจ่าย" fill="#ef4444" radius={[4,4,0,0]} />
            <Bar dataKey="profit" name="กำไร" fill="#3b82f6" radius={[4,4,0,0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Truck Summary */}
      {truckSummary.length > 0 && (
        <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <h2 className="font-bold text-gray-700 mb-4">สรุปแยกตามรถ</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100">
                  <th className="text-left py-2 text-gray-500 font-medium">ทะเบียน</th>
                  <th className="text-right py-2 text-gray-500 font-medium">จำนวนเที่ยว</th>
                  <th className="text-right py-2 text-gray-500 font-medium">รายรับ</th>
                  <th className="text-right py-2 text-gray-500 font-medium">รายจ่าย</th>
                  <th className="text-right py-2 text-gray-500 font-medium">กำไร</th>
                </tr>
              </thead>
              <tbody>
                {truckSummary.sort((a, b) => b.profit - a.profit).map(s => (
                  <tr key={s.truck.id} className="border-b border-gray-50">
                    <td className="py-2 font-medium text-gray-800">{s.truck.plate}</td>
                    <td className="text-right py-2 text-gray-600">{s.trips}</td>
                    <td className="text-right py-2 text-green-600 font-medium">฿{s.income.toLocaleString()}</td>
                    <td className="text-right py-2 text-red-500 font-medium">฿{s.expense.toLocaleString()}</td>
                    <td className={`text-right py-2 font-bold ${s.profit >= 0 ? 'text-blue-600' : 'text-orange-500'}`}>฿{s.profit.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}